<?php

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
$name=$_POST["name"];
$password=$_POST["password"];
$rollno=$_POST["rollno"];
$email=$_POST["email"];
$mobno=$_POST["mobno"];
$hostelno=$_POST["hostelno"];
$blockno=$_POST["blockno"];
$roomno=$_POST["roomno"];

					$con=mysqli_connect("localhost","gawdsin_gawdsin","KckZ6ZJ?38wm","gawdsin_emarket");
					if (mysqli_connect_errno())
					{
					echo "Failed to connect to MySQL: " . mysqli_connect_error();
					}
					echo "a";
					$result=mysqli_query($con,"SELECT * FROM userid WHERE rollno='$rollno'");
					$count=mysqli_fetch_array($result);
					if(!$count['rollno']){
					echo "sss";
					mysqli_query($con,"INSERT INTO userid (name,password,rollno,email,mobno,hostleno,blockno,roomno)
					VALUES ('$name','$password','$rollno','$email','$mobno','$hostelno','$blockno','$roomno')");
					}
					else
					 echo "Rollno all ready exist";

}



?>