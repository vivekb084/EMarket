<?php
session_start();
if(!empty($_SESSION['username']))
{
header("location:dashboard.php");
}
else
	session_destroy();
if(isset($_GET['message']))
{
$message=$_GET['message'];
echo '<script>alert('.'"'.$message.'"'.');</script>';
unset($_GET['message']);
}
else
{
}
 
?>

<!DOCTYPE HTML>
<html>
<head>

<title> Login </title>

</head>
<body>
<form action="login_auth.php" method="post">
Username(Roll no) : <input type="text" name="rollno"><br>
Password: <input type="password" name="password"><br>
<input type="submit" name="submit" value="Submit">


</form>

<body>