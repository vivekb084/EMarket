<?php
session_start();
if(!empty($_SESSION['username']))
{
$username=$_SESSION['username'];

}
else
{
session_destroy();
header("location:login.php?message=Login First!");
}
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
$productname=$_POST['productname'];
$price=$_POST['price'];
$sellerprice=$_POST['sellerprice'];
$description=$_POST['description'];
$bid=$_POST['bid'];


					$con=mysqli_connect("localhost","gawdsin_gawdsin","KckZ6ZJ?38wm","gawdsin_emarket");
					if (mysqli_connect_errno())
					{
					echo "Failed to connect to MySQL: " . mysqli_connect_error();
					}
					$result=mysqli_query($con,"SELECT * FROM userid WHERE rollno='$username'");
					$count=mysqli_fetch_array($result);
					if($count['uploadflag']==0)
					{
					$message="Image is not uploaded";
					echo '<script>alert('.'"'.$message.'"'.');</script>';
					}
					else{
					$productid="";
					$productid.=$username;
					$productid.="_";
					$productid.=$count['productcount'];
					mysqli_query($con,"INSERT INTO productinfo (productname,price,sellerprice,description,bid,addedby,productid,sold)
					VALUES ('$productname','$price','$sellerprice','$description','0','$username','$productid','1')");
					
					mysqli_query($con,"UPDATE userid SET productcount=$count[productcount]+1 WHERE rollno=$username");
					
					mysqli_query($con,"UPDATE userid SET uploadflag=0 WHERE rollno=$username");
					$mess="Product Uploaded!";
					echo '<script>alert('.'"'.$mess.'"'.');</script>';
					
					
					}
}


?>