<?php
session_start();
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$rollno=$_POST["rollno"];
$password=$_POST["password"];
					$con=mysqli_connect("localhost","gawdsin_gawdsin","KckZ6ZJ?38wm","gawdsin_emarket");
					if (mysqli_connect_errno())
					{
					echo "Failed to connect to MySQL: " . mysqli_connect_error();
					}
					echo "a";
					$result=mysqli_query($con,"SELECT * FROM userid WHERE rollno='$rollno' AND password='$password'");
					$count=mysqli_fetch_array($result);
					if($count)
					{
					$_SESSION['username']=$rollno;
					$_SESSION['name']=$count['name'];
					header("location:dashboard.php");
					}
					else
					{
					session_destroy();
					header("location:login.php?message=Wrong username or password");
					}
					

}


?>