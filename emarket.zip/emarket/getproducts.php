<?php
			$con=mysqli_connect("localhost","gawdsin_gawdsin","KckZ6ZJ?38wm","gawdsin_emarket");
			if (mysqli_connect_errno())
			{
				echo "Failed to connect to MySQL: " . mysqli_connect_error();
			}
			$pid = array();		
			$result=mysqli_query($con,"SELECT * FROM productinfo ");
			$n = mysqli_num_rows($result);
			$row = mysqli_fetch_array($result);
			for($i=0;$i<$n;$i++)
			$pid['$i'] = $row['productid'];
			echo json_encode($pid);
?>
